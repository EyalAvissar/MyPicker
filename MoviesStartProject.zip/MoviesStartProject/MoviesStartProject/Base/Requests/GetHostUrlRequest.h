//
//  GetHostUrlRequest.h
//  Meshulam
//
//  Created by inmanage on 8/17/15.
//  Copyright (c) 2015 inmanage. All rights reserved.
//

#import "BaseRequest.h"

@interface GetHostUrlRequest : BaseRequest

-(NSString*)getMethodName;

@end
