//
//  SetSettingsResponse.m
//  MoviesStartProject
//
//  Created by inmanage on 25/10/2021.
//

#import "SetSettingsResponse.h"

@implementation SetSettingsResponse

@end
