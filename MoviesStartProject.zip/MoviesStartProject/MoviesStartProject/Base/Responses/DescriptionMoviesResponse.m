//
//  DescriptionMoviesResponse.m
//  MoviesStartProject
//
//  Created by inmanage on 25/10/2021.
//

#import "DescriptionMoviesResponse.h"

@implementation DescriptionMoviesResponse

@end
