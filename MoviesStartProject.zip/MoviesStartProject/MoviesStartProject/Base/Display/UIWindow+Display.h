//
//  UIWindow+Display.h
//  MoviesStartProject
//
//  Created by inmanage on 28/10/2021.
//

#ifndef UIWindow_Display_h
#define UIWindow_Display_h

#import <UIKit/UIKit.h>

@interface UIWindow (DisplayChange)

- (UIViewController *) visibleViewController;

@end

#endif /* UIWindow_Display_h */
