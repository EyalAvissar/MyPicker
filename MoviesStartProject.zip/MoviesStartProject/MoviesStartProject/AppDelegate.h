//
//  AppDelegate.h
//  MoviesStartProject
//
//  Created by inmanage on 24/10/2021.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

+(AppDelegate *)sharedDelegate;

@end

